# quickstats
A library of common statistical utility functions.

## building this package locally
`python setup.py sdist`

## installing this package from GitHub
`pip install git+https://github.com/glenad/quick-stats.git`

## updating this package from GitHub
`pip install --upgrade git+https://github.com/glenad/quick-stats.git`